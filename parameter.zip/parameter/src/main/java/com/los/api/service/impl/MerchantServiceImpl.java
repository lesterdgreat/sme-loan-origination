package com.los.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.los.api.constant.Constants;
import com.los.api.dto.RecordDto;
import com.los.api.dto.StatusDto;
import com.los.api.dto.merchant.MerchantDto;
import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.dto.merchant.MerchantRespDto;
import com.los.api.dto.parameter.ParameterDto;
import com.los.api.dto.parameter.ParameterRespDto;
import com.los.api.model.LoanType;
import com.los.api.model.Merchant;
import com.los.api.model.Parameter;
import com.los.api.model.Queue;
import com.los.api.repository.LoanTypeRepository;
import com.los.api.repository.MerchantRepository;
import com.los.api.repository.MerchantSpecification;
import com.los.api.repository.ParameterRepository;
import com.los.api.repository.QueueRepository;
import com.los.api.repository.impl.MerchantRepositoryCustom;
import com.los.api.service.MerchantService;
import com.los.api.service.ParameterService;
import com.los.api.utility.JsonUtility;


@Service
public class MerchantServiceImpl implements MerchantService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantServiceImpl.class);
	
	@Autowired
	private MerchantRepository merchantRepository;

	@Override
	public MerchantRespDto searchMerchant(MerchantReqDto reqDto) throws Exception {
		MerchantRespDto respDto = new MerchantRespDto();
		
		Pageable pageRequest = PageRequest.of(reqDto.getRecord().getPage() - 1 , reqDto.getRecord().getMaxRows()); 
		LOGGER.info("searchMerchant | pageRequest= " + pageRequest);
		
//		Page<Merchant> merchantPage = merchantRepository.findAll(MerchantSpecification.searchCriteria(reqDto), pageRequest);
		Page<Merchant> merchantPage = merchantRepository.findAll(pageRequest);
		LOGGER.info("searchMerchant | merchantPage= " + merchantPage);
		
		List<Merchant> list = merchantRepository.search(reqDto, pageRequest);
		LOGGER.info("searchMerchant | list= " + list);
		
		if (!merchantPage.isEmpty()) {
		
			List<Merchant> merchantList = merchantPage.getContent();
//			LOGGER.info("searchMerchant | merchantList= " + merchantList);
			
			List<MerchantDto> merchantDtoList = JsonUtility.transferToList(merchantList, MerchantDto.class);
//			LOGGER.info("searchMerchant | merchantDtoList= " + merchantDtoList);
			
			respDto.setMerchantList(merchantDtoList);
		
		}
		
		RecordDto recordDto = new RecordDto();
		recordDto.setPage(merchantPage.getNumber() + 1);
//		recordDto.setMaxRows(reqDto.getRecord().getMaxRows());
		recordDto.setTotalItems(Long.valueOf(merchantPage.getTotalElements()).intValue());
		recordDto.setTotalPages(merchantPage.getTotalPages());

		respDto.setRecord(recordDto);
		
		respDto.setStatusDto(new StatusDto().setSuccess());
		
		return respDto;
	}

}
