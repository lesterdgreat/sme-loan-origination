package com.los.api.constant;

public class UriConstants {

	// Base URI
	public static final String BASE_URI = "/api";
	
	// Module URI
	public static final String PARAM = BASE_URI + "/param";
	
	// URI
	public static final String MERCHANT = "/merchant";
	
}
