package com.los.api.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.model.Merchant;
import com.los.api.repository.impl.MerchantRepositoryCustom;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Repository
public interface MerchantRepository extends JpaRepository<Merchant, String>, JpaSpecificationExecutor<Merchant>, MerchantRepositoryCustom {
	

//	record MerchSpecification() implements Specification<Merchant> {
//
//        public Predicate toPredicate(Root<Merchant> root,
//                                      CriteriaQuery<?> query,
//                                      CriteriaBuilder builder) {
//
//            Predicate predicate = builder.conjunction();
//            List<Expression<Boolean>> exps = predicate.getExpressions();
//
//          exps.add(builder.like(builder.lower(root.get("title")), ""));
//
//            return predicate;
//        }
//    }
}
