package com.los.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.los.api.constant.Constants;
import com.los.api.dto.StatusDto;
import com.los.api.dto.parameter.ParameterDto;
import com.los.api.dto.parameter.ParameterRespDto;
import com.los.api.model.LoanType;
import com.los.api.model.Parameter;
import com.los.api.model.Queue;
import com.los.api.repository.LoanTypeRepository;
import com.los.api.repository.ParameterRepository;
import com.los.api.repository.QueueRepository;
import com.los.api.service.ParameterService;
import com.los.api.utility.JsonUtility;


@Service
public class ParameterServiceImpl implements ParameterService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ParameterServiceImpl.class);
	
	@Autowired
	private ParameterRepository parameterRepository;
	
	@Autowired
	private LoanTypeRepository loanTypeRepository;
	
	@Autowired
	private QueueRepository queueRepository;


	@Override
	public ParameterRespDto getParamById(String paramId) throws Exception {
		ParameterRespDto paramRespDto = new ParameterRespDto();
		List<ParameterDto> parameterList = new ArrayList<ParameterDto>();
		
		if (paramId.equals(Constants.PARAM_LOAN_TYPE)) {
			
			List<LoanType> list = loanTypeRepository.findAll();
			LOGGER.info("list = " + list);
			
			parameterList = JsonUtility.transferToList(list, ParameterDto.class);
			LOGGER.info("parameterList = " + parameterList);
			
		} else if (paramId.equals(Constants.PARAM_QUEUE)) {
			
			List<Queue> list = queueRepository.findAll();
			LOGGER.info("list = " + list);
			
			parameterList = JsonUtility.transferToList(list, ParameterDto.class);
			LOGGER.info("parameterList = " + parameterList);
			
		} else {
		
			List<Parameter> list = parameterRepository.findByParamId(paramId);
			LOGGER.info("list = " + list);
			
			parameterList = JsonUtility.transferToList(list, ParameterDto.class);
			LOGGER.info("parameterList = " + parameterList);
			
		}
		
		paramRespDto.setParameterList(parameterList);
		
		paramRespDto.setStatusDto(new StatusDto().setSuccess());
		
		return paramRespDto;
	}

}
