package com.los.api.dto.merchant;

import java.util.List;

import com.los.api.dto.RecordDto;
import com.los.api.dto.StatusDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MerchantRespDto {

	private StatusDto statusDto;

	private List<MerchantDto> merchantList;
	
	private RecordDto record;

}
