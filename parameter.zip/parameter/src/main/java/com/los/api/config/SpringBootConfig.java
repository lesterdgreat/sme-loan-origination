package com.los.api.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.los.api.constant.ConfigConstants;
import com.los.api.utility.ConfigUtility;

@SpringBootApplication
@ComponentScan(basePackages = { ConfigConstants.BASE_PACKAGE_ALL })
@EntityScan(basePackages = { ConfigConstants.BASE_PACKAGE_DTO, ConfigConstants.BASE_PACKAGE_MODEL })
@EnableJpaRepositories(basePackages = { ConfigConstants.BASE_PACKAGE_REPOSITORY })
public class SpringBootConfig extends SpringBootServletInitializer {

	public static final String PROPERTY_PATH;

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringBootConfig.class);

	static {
		PROPERTY_PATH = ConfigUtility.getPropertyPath(ConfigConstants.PATH_PROJ_CONFIG,
				ConfigConstants.FILE_SYS_RESOURCE, ConfigConstants.PROPERTY_FILENAME);
	}	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootConfig.class, args);
		LOGGER.info("LOS (SME) API - Parameter Spring Boot started...");
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		application.bannerMode(Banner.Mode.OFF);
		return application.sources(SpringBootConfig.class);
	}

}
