package com.los.api.constant;


public class MediaType {

	public static final String APPLICATION_JSON = "application/json";
	
}
