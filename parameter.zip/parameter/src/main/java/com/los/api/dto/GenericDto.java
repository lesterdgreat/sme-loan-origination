package com.los.api.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenericDto implements Serializable {

	private static final long serialVersionUID = -220808408117326108L;

	@JsonProperty("status")
	private StatusDto statusDto;
}
