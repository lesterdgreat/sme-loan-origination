package com.los.api.dto.merchant;


import com.los.api.dto.parameter.ParameterDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BranchDto {
	
	private String branchCode;
	
	private String name;
	
	private ParameterDto region;

}
