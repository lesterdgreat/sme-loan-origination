package com.los.api.utility;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.los.api.constant.Constants;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
public class JsonDateTimeSerializer extends JsonSerializer<Date> {

	@Override
	public void serialize(Date date, JsonGenerator gen, SerializerProvider provider) throws IOException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DT_DD_MM_YYYY_SLASH_TIME_S);
		gen.writeString(dateFormat.format(date));
	}

}
