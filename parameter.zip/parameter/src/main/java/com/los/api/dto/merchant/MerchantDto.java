package com.los.api.dto.merchant;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MerchantDto {

	private String merchantCode1;
	
	private String merchantCode2;
	
	private String merchantName1;
	
	private String merchantName2;
	
	private BranchDto branch;

}
