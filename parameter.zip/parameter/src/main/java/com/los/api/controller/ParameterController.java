package com.los.api.controller;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.los.api.constant.MediaType;
import com.los.api.constant.QualifierConstants;
import com.los.api.constant.UriConstants;
import com.los.api.dto.StatusDto;
import com.los.api.dto.parameter.ParameterRespDto;
import com.los.api.service.ParameterService;
import com.los.api.utility.JsonUtility;


@RestController
@RequestMapping(UriConstants.PARAM)
public class ParameterController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ParameterController.class);
	
	@Autowired
	@Qualifier(QualifierConstants.PARAMETER_SERVICE_IMPL)
	private ParameterService parameterService;

	@GetMapping(value = "/{paramId}", produces = { MediaType.APPLICATION_JSON })
	public ResponseEntity<?> getParamById(@PathVariable("paramId") String paramId) {
		ParameterRespDto paramRespDto = null;
		try {
			paramRespDto = parameterService.getParamById(paramId);
			
			LOGGER.info("getParamById | Response JSON : " +  JsonUtility.objectMapper().writeValueAsString(paramRespDto));
			
		} catch (Exception e) {
			LOGGER.error("getParamById | Error: ", e);
			e.printStackTrace();
			paramRespDto.setStatusDto(new StatusDto(new Timestamp(new Date().getTime()), HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e.toString(), ""));
		}
		
		return ResponseEntity.ok(paramRespDto);
		
	}
}
