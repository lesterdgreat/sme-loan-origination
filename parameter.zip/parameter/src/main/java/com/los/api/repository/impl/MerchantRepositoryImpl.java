package com.los.api.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.plexus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;

import com.los.api.constant.Constants;
import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.model.Branch;
import com.los.api.model.Merchant;
import com.los.api.service.impl.MerchantServiceImpl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
public class MerchantRepositoryImpl implements MerchantRepositoryCustom {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantRepositoryImpl.class);
	
	@PersistenceContext
    private EntityManager em;

	
	public List<Merchant> search(MerchantReqDto reqDto, Pageable pageRequest) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
	    CriteriaQuery<Merchant> cq = cb.createQuery(Merchant.class);

	    Root<Merchant> root = cq.from(Merchant.class);
	    List<Predicate> predicates = new ArrayList<>();

	    if(!StringUtils.isEmpty(reqDto.getMerchantCode1()))
	        predicates.add(cb.equal(root.get("merchantCode1"), reqDto.getMerchantCode1()));
	    
	    if (!StringUtils.isEmpty(reqDto.getMerchantCode2()))
	        predicates.add(cb.equal(root.get("merchantCode2"), reqDto.getMerchantCode2()));
	    
	    if (!StringUtils.isEmpty(reqDto.getMerchantName1()))
	        predicates.add(cb.like(root.get("merchantName1"), Constants.PERCENT + reqDto.getMerchantName1() + Constants.PERCENT));
	    
	    if (!StringUtils.isEmpty(reqDto.getMerchantName2()))
	        predicates.add(cb.like(root.get("merchantName2"), Constants.PERCENT + reqDto.getMerchantName2() + Constants.PERCENT));
	    
	    if (!StringUtils.isEmpty(reqDto.getBranch()))
	        predicates.add(cb.equal(root.get("branchCode"), reqDto.getBranch()));
	    
	    if(!StringUtils.isEmpty(reqDto.getRegion())){
    		Join<Merchant, Branch> branchJoin = root.join("branch");
    		predicates.add(cb.equal(branchJoin.get("regionCode"), reqDto.getRegion()));
		}
	    
	    cq.where(predicates.toArray(new Predicate[predicates.size()]));
	    
	    List<Merchant> l = em.createQuery(cq).getResultList();
	    
//	    Long totalCount = new Integer(em.createQuery(cq).getResultList().size()).longValue();
	    
	    Long totalCount = new Integer(l.size()).longValue();
	    
	    Page<Merchant> g = PageableExecutionUtils.getPage(l,pageRequest, () -> totalCount);
	    LOGGER.info("g= " + g);
	    LOGGER.info("getContent= " + g.getContent());

	    return em.createQuery(cq)
//	    		.setMaxResults(reqDto.getRecord().getMaxRows())
//	    		.setFirstResult(getFirstResult(reqDto.getRecord().getPage() - 1))
	    		.setMaxResults(pageRequest.getPageSize())
	    		.setFirstResult(getFirstResult(pageRequest))
	    		.getResultList();
	}
	
	private Integer getFirstResult(Pageable pageRequest) {
		int firstResultIndex = pageRequest.getPageNumber() * pageRequest.getPageSize();
		System.out.println("firstResultIndex " + firstResultIndex);
		return firstResultIndex;
	}

}
