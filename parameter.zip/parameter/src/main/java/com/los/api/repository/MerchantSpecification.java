package com.los.api.repository;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.plexus.util.StringUtils;

import org.springframework.data.jpa.domain.Specification;

import com.los.api.constant.Constants;
import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.model.Branch;
import com.los.api.model.Merchant;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.Builder;
import lombok.Data;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@Builder
public class MerchantSpecification {	
	
	@PersistenceContext
    private static EntityManager em;

	public static Specification<Merchant> searchCriteria(MerchantReqDto reqDto){
	    return (root, query, criteriaBuilder) -> {
	    	
//	    	Predicate p = criteriaBuilder.conjunction();
//	    	
//	    	if(!StringUtils.isEmpty(reqDto.getMerchantCode1()))
//				p = criteriaBuilder.and(p, criteriaBuilder.equal(root.get("merchantCode1"), reqDto.getMerchantCode1()));
//	    	
//	    	if(!StringUtils.isEmpty(reqDto.getMerchantCode2()))
//				p = criteriaBuilder.and(p, criteriaBuilder.equal(root.get("merchantCode2"), reqDto.getMerchantCode2()));
//	    	
//	    	if(!StringUtils.isEmpty(reqDto.getMerchantName1()))
//				p = criteriaBuilder.and(p, criteriaBuilder.like(root.get("merchantName1"), Constants.PERCENT + reqDto.getMerchantName1() + Constants.PERCENT));
//	    	
//	    	if(!StringUtils.isEmpty(reqDto.getMerchantName2()))
//				p = criteriaBuilder.and(p, criteriaBuilder.like(root.get("merchantName2"), Constants.PERCENT + reqDto.getMerchantName2() + Constants.PERCENT));
//	    	
//	    	if(!StringUtils.isEmpty(reqDto.getBranch()))
//				p = criteriaBuilder.and(p, criteriaBuilder.equal(root.get("branchCode"), reqDto.getBranch()));
//
//	    	if(!StringUtils.isEmpty(reqDto.getRegion())){
//	    		Join<Merchant, Branch> branchJoin = root.join("branch");
//	    		
//	    		p = criteriaBuilder.and(p, criteriaBuilder.equal(branchJoin.get("regionCode"), reqDto.getRegion()));
//			}
				
//			return p;
	    	return null;
	    };
	}  
	
	public static Specification<Merchant> search2(MerchantReqDto reqDto){
		
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
		
		Predicate p = cb.conjunction();
		
	    CriteriaQuery<Merchant> cq = cb.createQuery(Merchant.class);

	    Root<Merchant> merchant = cq.from(Merchant.class);
	    List<Predicate> predicates = new ArrayList<>();

	    if (reqDto.getMerchantCode1() != null) {
	        predicates.add(cb.like(merchant.get("merchantCode1"), "%" + reqDto.getMerchantCode1() + "%"));
	    }
	    cq.where(predicates.toArray(new Predicate[0]));
		
	    
	    return null;	
		
	}
	
	
	public static Predicate toPredicate(Root<Merchant> root, CriteriaQuery<?> query, CriteriaBuilder builder) {

		List<Predicate> exps = new ArrayList<>();
		
		exps.add(builder.like(builder.lower(root.get("merchantCode1")), ""));
		
		return builder.and(exps.toArray(new Predicate[0]));
	}
	
	public static List<Expression<Boolean>> getExpressions(MerchantReqDto reqDto) {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Merchant> cq = cb.createQuery(Merchant.class);
		Root<Merchant> root = cq.from(Merchant.class);
		
		List<Predicate> exps = new ArrayList<>();
		
		exps.add(cb.like(cb.lower(root.get("merchantCode1")), ""));
		
//		return cb.and(exps.toArray(new Predicate[0]));
		
        return new ArrayList<>( exps );
    }

	

}
