package com.los.api.constant;

public class MessageConstants {
	
	public static final String MSG_SUCCESS = "SUCCESS";
	
	public static final String MSG_ERROR = "ERROR";
	
	public static final String MSG_EXCEPTION = "EXCEPTION";
	
	public static final String ERROR_ID = "LMTERR: ";
	
	public static final String MSG_LIMIT_NOT_FOUND = ERROR_ID + "Limit not found.";
	
}
