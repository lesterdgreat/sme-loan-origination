package com.los.api.service;

import com.los.api.dto.parameter.ParameterRespDto;

public interface ParameterService {

	ParameterRespDto getParamById(String paramId) throws Exception;
	
}
