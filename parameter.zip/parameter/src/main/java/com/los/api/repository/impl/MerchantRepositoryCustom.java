package com.los.api.repository.impl;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.model.Merchant;


/**
 * 
 * @author USER
 * @since 7/10/2023
 */
public interface MerchantRepositoryCustom {
	
	List<Merchant> search(MerchantReqDto reqDto, Pageable pageRequest);
}
