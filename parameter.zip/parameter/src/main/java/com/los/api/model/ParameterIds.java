package com.los.api.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParameterIds implements Serializable {

	private static final long serialVersionUID = 1L;

	private String paramId;

	private String key;

}
