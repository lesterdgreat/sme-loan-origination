package com.los.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbm_queue")
@Access(value = AccessType.FIELD)
public class Queue {

	@Id
	@Column(name = "que_queueid")
	@JsonProperty("key")
	private int queueId;

	@Column(name = "que_name")
	@JsonProperty("value")
	private String name;
	
	@Column(name = "que_sequence")
	private int sequence;

}
