package com.los.api.dto.parameter;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.los.api.dto.StatusDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParameterRespDto {

	@JsonProperty("status")
	private StatusDto statusDto;

	@JsonProperty("parameter_list")
	private List<ParameterDto> parameterList;

}
