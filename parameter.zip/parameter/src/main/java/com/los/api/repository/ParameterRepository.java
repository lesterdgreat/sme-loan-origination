package com.los.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.los.api.model.Parameter;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Repository
public interface ParameterRepository extends JpaRepository<Parameter, String> {

	List<Parameter> findByParamId(String paramId);

}
