package com.los.api.model;

import java.io.Serializable;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Where;

import com.los.api.constant.Constants;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbm_branch")
@Access(value = AccessType.FIELD)
public class Branch implements Serializable {

	private static final long serialVersionUID = 501829647647215412L;
	
	@Id
	@Column(name = "brn_branchcode")
	private String branchCode;
	
	@Column(name = "brn_name")
	private String name;
	
	@Column(name = "brn_regioncode")
	private String regionCode;	
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "brn_regioncode", referencedColumnName="prm_key", insertable=false, updatable=false, nullable=true)
	@NotFound(action = NotFoundAction.IGNORE)
	@Where(clause ="prm_paramid = '"+ Constants.PARAM_REGION +"'")
	private Parameter region;
	
}
