package com.los.api.constant;

import java.io.File;

public class ConfigConstants {

	private ConfigConstants() {
		throw new IllegalStateException(ConfigConstants.class.getName());
	}

	public static final String BASE_PACKAGE = "com.los.api";
	
	public static final String BASE_PACKAGE_ALL = BASE_PACKAGE + ".*";
	
	public static final String BASE_PACKAGE_DTO = BASE_PACKAGE + ".dto";
	
	public static final String BASE_PACKAGE_MODEL = BASE_PACKAGE + ".model";
	
	public static final String BASE_PACKAGE_REPOSITORY = BASE_PACKAGE + ".repository";

	public static final String CACHE_JAVA_FILE = "T(" + BASE_PACKAGE + ".sdk.constants.CacheConstants)";

	public static final String PATH_PROJ_CONFIG = "lossme.config.path";
	
	public static final String PATH_PROJ_CONFIG_OTH = "lossme-oth.config.path";

	public static final String PROPERTY_FILENAME = "parameter";

	public static final String FILE_PFX = "file:";

	public static final String PROPERTIES_EXT = ".properties";

	public static final String FILE_SYS_RESOURCE = File.separator + PROPERTY_FILENAME + ConfigConstants.PROPERTIES_EXT;

	private static final String CLASSPATH_PFX = "classpath:";

	public static final String PROPERTY_CLASSPATH = ConfigConstants.CLASSPATH_PFX + PROPERTY_FILENAME;
	
}
