package com.los.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.los.api.model.Queue;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
public interface QueueRepository extends JpaRepository<Queue, Integer> {

}
