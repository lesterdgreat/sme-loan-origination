package com.los.api.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecordDto implements Serializable {

	private static final long serialVersionUID = -220808408117326108L;

	private Integer page;
	
	private Integer maxRows;
	
	private Integer totalItems;
	
	private Integer totalPages;

}
