package com.los.api.dto.parameter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParameterDto {
	
	private String key;

	private String value;

}
