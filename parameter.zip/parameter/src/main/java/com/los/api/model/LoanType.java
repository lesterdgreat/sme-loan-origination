package com.los.api.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbm_loantype")
@Access(value = AccessType.FIELD)
public class LoanType {

	@Id
	@Column(name = "lntp_loantypeid")
	@JsonProperty("key")
	private int loanTypeId;

	@Column(name = "lntp_name")
	@JsonProperty("value")
	private String name;
	
	@Column(name = "lntp_producttype")
	private String productType;

	@Column(name = "lntp_enable")
	private int enable;
	
	@Column(name = "lntp_createdby")
	private String createdBy;
	
	@Column(name = "lntp_createddate")
	private LocalDateTime createdDate;
	
	@Column(name = "lntp_updatedby")
	private String updatedBy;
	
	@Column(name = "lntp_updateddate")
	private LocalDateTime updatedDate;
}
