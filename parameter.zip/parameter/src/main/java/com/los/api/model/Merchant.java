package com.los.api.model;

import java.io.Serializable;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbm_merchant")
@Access(value = AccessType.FIELD)
@IdClass(MerchantIds.class)
public class Merchant implements Serializable {
	
	private static final long serialVersionUID = 8603252139776075710L;

	@Id
	@Column(name = "mrc_merchantcode1")
	private String merchantCode1;

	@Id
	@Column(name = "mrc_merchantcode2")
	private String merchantCode2;
	
	@Column(name = "mrc_merchantname1")
	private String merchantName1;

	@Column(name = "mrc_merchantname2")
	private String merchantName2;	
	
	@Column(name = "mrc_acsbranch")
	private String acsBranch;	
	
	@Column(name = "mrc_branchcode")
	private String branchCode;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "mrc_branchcode", referencedColumnName="brn_branchcode", insertable=false, updatable=false, nullable=true)
	@NotFound(action = NotFoundAction.IGNORE)
	private Branch branch;

}
