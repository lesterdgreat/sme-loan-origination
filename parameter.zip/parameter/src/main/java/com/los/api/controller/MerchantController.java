package com.los.api.controller;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.los.api.constant.MediaType;
import com.los.api.constant.QualifierConstants;
import com.los.api.constant.UriConstants;
import com.los.api.dto.StatusDto;
import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.dto.merchant.MerchantRespDto;
import com.los.api.service.MerchantService;
import com.los.api.utility.JsonUtility;


@RestController
@RequestMapping(UriConstants.PARAM)
public class MerchantController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantController.class);
	
	@Autowired
	@Qualifier(QualifierConstants.MERCHANT_SERVICE_IMPL)
	private MerchantService merchantService;

	@PostMapping(value = UriConstants.MERCHANT, produces = { MediaType.APPLICATION_JSON }, consumes = { MediaType.APPLICATION_JSON })
	public ResponseEntity<?> searchMerchant(@RequestBody MerchantReqDto reqDto) {
		MerchantRespDto respDto = null;
		try {
			
			LOGGER.info("searchMerchant | Request JSON : " +  JsonUtility.objectMapper().writeValueAsString(reqDto));
			
			respDto = merchantService.searchMerchant(reqDto);
			
			LOGGER.info("searchMerchant | Response JSON : " +  JsonUtility.objectMapper().writeValueAsString(respDto));
			
		} catch (Exception e) {
			LOGGER.error("searchMerchant | Error: ", e);
			e.printStackTrace();
			respDto.setStatusDto(new StatusDto(new Timestamp(new Date().getTime()), HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e.toString(), ""));
		}
		
		return ResponseEntity.ok(respDto);
		
	}
}
