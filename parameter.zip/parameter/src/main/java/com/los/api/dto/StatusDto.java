package com.los.api.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.los.api.constant.Constants;
import com.los.api.constant.MessageConstants;
import com.los.api.utility.JsonDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatusDto implements Serializable {

	private static final long serialVersionUID = -220808408117326108L;

	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DT_DD_MM_YYYY_SLASH_TIME_S)
	private Timestamp timestamp;

	private int status;

	private String code;

	private String message;

	private String path;
	
	public StatusDto setSuccess() {
		return new StatusDto(new Timestamp(new Date().getTime()), HttpStatus.OK.value(), HttpStatus.OK.getReasonPhrase(), MessageConstants.MSG_SUCCESS, "");
	}

}
