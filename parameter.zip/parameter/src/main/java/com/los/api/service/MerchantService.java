package com.los.api.service;

import com.los.api.dto.merchant.MerchantReqDto;
import com.los.api.dto.merchant.MerchantRespDto;

public interface MerchantService {

	MerchantRespDto searchMerchant(MerchantReqDto reqDto) throws Exception;
	
}
