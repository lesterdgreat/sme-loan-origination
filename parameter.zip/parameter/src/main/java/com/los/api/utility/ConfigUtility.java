package com.los.api.utility;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigUtility.class);

	private ConfigUtility() {

	}

	/**
	 * Gets the property path.
	 *
	 * @param pathProjConfig  the path proj config
	 * @param fileSysResource the file sys resource
	 * @param propFilename    the prop filename
	 * @return the property path
	 */
	public static String getPropertyPath(String pathProjConfig, String fileSysResource, String propFilename) {
		String propertyPath = null;

		// Get from PROJECT CONFIGURATION server
		String propertyHome = System.getProperty(pathProjConfig) != null ? System.getProperty(pathProjConfig)
				: System.getenv(pathProjConfig);
		LOGGER.debug("PROJECT CONFIGURATION HOME >> {}", propertyHome);
		File file = new File(propertyHome + fileSysResource);
		if (!file.exists()) {
			propertyHome = null;
		}

		if (!Utility.isObjNull(propertyHome)) {
			file = new File(propertyHome + fileSysResource);
			if (file.exists() && !file.isDirectory()) {
				propertyPath = propertyHome + File.separator + propFilename;
			} else {
				LOGGER.error("Missing properties file >> {}{}", propertyHome, fileSysResource);
			}
		}

		String propClasspath = "classpath:" + propFilename;

		// Get from Application CLASSPATH
		propertyPath = propertyPath != null ? propertyPath : propClasspath;

		LOGGER.info("Application Properties Path: {}", propertyPath);

		return propertyPath;

	}
}
