package com.los.api.constant;

public class QualifierConstants {

	private QualifierConstants() {
		// Block Initialization 
	}
	
	public static final String PARAMETER_SERVICE_IMPL = "parameterServiceImpl";
	
	public static final String MERCHANT_SERVICE_IMPL = "merchantServiceImpl";
}
