package com.los.api.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author USER
 * @since 7/10/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tbm_parameter")
@Access(value = AccessType.FIELD)
@IdClass(ParameterIds.class)
public class Parameter implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "prm_paramid")
	private String paramId;

	@Id
	@Column(name = "prm_key")
	private String key;

	@Column(name = "prm_value")
	private String value;

	@Column(name = "prm_bnmcode")
	private String bnmCode;

	@Column(name = "prm_displayflag")
	private Integer displayFlag;

	@Column(name = "prm_createdby")
	private String createdBy;

	@Column(name = "prm_createddate")
	private LocalDateTime createdDate;
	
	@Column(name = "prm_updatedby")
	private String updatedBy;

	@Column(name = "prm_updateddate")
	private LocalDateTime updatedDate;

}
